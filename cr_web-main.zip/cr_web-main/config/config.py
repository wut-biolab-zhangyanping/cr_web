pht_threshold_texture = 1e-4
pd_save_path = r"/home/zyp/project/EI_SEG/dataset/soybean_texture_pd"
image_source_path = r"/home/zyp/project/EI_SEG/dataset/soybean_origin_img"
